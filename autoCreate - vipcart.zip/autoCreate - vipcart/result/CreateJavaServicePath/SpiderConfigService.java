package com.jd.o2o.vipcart.service.base;

import com.jd.o2o.road.common.service.BaseService;
import com.jd.o2o.vipcart.domain.entity.SpiderConfigEntity;

public interface SpiderConfigService extends BaseService<SpiderConfigEntity,Long>{
	
}