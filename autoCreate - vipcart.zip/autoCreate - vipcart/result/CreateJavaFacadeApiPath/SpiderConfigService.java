package com.jd.o2o.vipcart.api;
import com.jd.o2o.commons.domain.PageBean;
import com.jd.o2o.commons.domain.response.ServiceResponse;
import com.jd.o2o.vipcart.domain.request.SpiderConfigRequest;
import com.jd.o2o.vipcart.domain.response.SpiderConfigResponse;
import java.util.List;

public interface SpiderConfigService {
	public ServiceResponse<List<SpiderConfigResponse>> findListSpiderConfig(SpiderConfigRequest spiderConfigRequest);
	public ServiceResponse<PageBean<SpiderConfigResponse>> findListPageSpiderConfig(SpiderConfigRequest spiderConfigRequest,PageBean<SpiderConfigResponse> pageQuery);
	public ServiceResponse<Integer> saveSpiderConfig(SpiderConfigRequest spiderConfigRequest);
	public ServiceResponse<Long> saveSpiderConfigBackId(SpiderConfigRequest spiderConfigRequest);
	public ServiceResponse<SpiderConfigResponse> findSpiderConfigById(Long id);
	public ServiceResponse<Integer> updateSpiderConfig(SpiderConfigRequest spiderConfigRequest);
	public ServiceResponse<Integer> deleteSpiderConfig(Long id);
	public ServiceResponse<Integer> deleteAllSpiderConfig(Long[] ids);
	public ServiceResponse<Integer> saveAllSpiderConfig(List<SpiderConfigRequest> spiderConfigRequestList);
	public ServiceResponse<Integer> updateAllSpiderConfig(List<SpiderConfigRequest> spiderConfigRequestList);

}
