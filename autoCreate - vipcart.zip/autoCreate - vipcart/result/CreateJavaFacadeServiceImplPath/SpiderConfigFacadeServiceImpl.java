package com.jd.o2o.vipcart.facade;

import com.jd.o2o.commons.domain.PageBean;
import com.jd.o2o.commons.domain.response.BaseResponseCode;
import com.jd.o2o.commons.domain.response.ServiceResponse;
import com.jd.o2o.commons.utils.json.JsonUtils;
import ;
import com.jd.o2o.road.common.domain.BaseMsgException;
import com.jd.o2o.road.common.utils.BeanHelper;
import com.jd.o2o.vipcart.domain.entity.SpiderConfigEntity;
import com.jd.o2o.vipcart.domain.request.SpiderConfigRequest;
import com.jd.o2o.vipcart.domain.response.SpiderConfigResponse;
import com.jd.o2o.vipcart.service.base.SpiderConfigService;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

@Service
public class SpiderConfigFacadeServiceImpl implements SpiderConfigFacadeService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SpiderConfigFacadeServiceImpl.class);
	@Resource
	private SpiderConfigService spiderConfigServiceImpl;
	
	@Override
	public ServiceResponse<List<SpiderConfigResponse>> findListSpiderConfig(SpiderConfigRequest spiderConfigRequest) {
        try{
            return new ServiceResponse(BeanHelper.copyTo(
                    spiderConfigServiceImpl.findList(BeanHelper.copyTo(spiderConfigRequest,SpiderConfigEntity.class)),
                    SpiderConfigResponse.class));
        } catch (BaseMsgException e) {
            LOGGER.error(String.format("查询列表信息出错！入参：[%s]",new Object[]{spiderConfigRequest}), e);
            return new ServiceResponse<List<SpiderConfigResponse>>(BaseResponseCode.FAILURE,e.getMessage());
        } catch (Exception e){
            LOGGER.error(String.format("查询列表信息出错！入参：[%s]",new Object[]{spiderConfigRequest}), e);
            return new ServiceResponse<List<SpiderConfigResponse>>(BaseResponseCode.SYSTEM_ERROR.getCode(),e.getMessage());
        }
    }

    @Override
    public ServiceResponse<PageBean<SpiderConfigResponse>> findListPageSpiderConfig(SpiderConfigRequest spiderConfigRequest,PageBean<SpiderConfigResponse> pageQuery) {
        try{
            PageBean<SpiderConfigEntity> pageBean = new PageBean<SpiderConfigEntity>(pageQuery.getPageNo(),pageQuery.getPageSize());
            spiderConfigServiceImpl.pageQuery(BeanHelper.copyTo(spiderConfigRequest,SpiderConfigEntity.class),pageBean);
            Collection <SpiderConfigResponse> entityList = BeanHelper.copyTo(pageBean.getResultList(),SpiderConfigResponse.class);
            pageQuery.setTotalCount(pageBean.getTotalCount());
            pageQuery.setResultList(entityList);
            return new ServiceResponse<PageBean<SpiderConfigResponse>>(pageQuery);
        } catch (BaseMsgException e) {
						LOGGER.error(String.format("查询列表信息出错！入参：[%s]",new Object[]{spiderConfigRequest}), e);
            return new ServiceResponse<PageBean<SpiderConfigResponse>>(BaseResponseCode.FAILURE,e.getMessage());
        } catch (Exception e){
            LOGGER.error(String.format("查询列表信息出错！入参：[%s]",new Object[]{spiderConfigRequest}), e);
            return new ServiceResponse<PageBean<SpiderConfigResponse>>(BaseResponseCode.SYSTEM_ERROR.getCode(),e.getMessage());
        }
    }

    @Override
    public ServiceResponse<Integer> saveSpiderConfig(SpiderConfigRequest spiderConfigRequest) {
        try{
            return new ServiceResponse<Integer>(spiderConfigServiceImpl.save(BeanHelper.copyTo(spiderConfigRequest,SpiderConfigEntity.class)));
        } catch (BaseMsgException e) {
						LOGGER.error(String.format("保存信息出错！入参：[%s]",new Object[]{spiderConfigRequest}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.FAILURE,e.getMessage());
        } catch (Exception e){
            LOGGER.error(String.format("保存信息出错！入参：[%s]",new Object[]{spiderConfigRequest}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.SYSTEM_ERROR.getCode(),e.getMessage());
        }
    }
	
	@Override
	public ServiceResponse<Long> saveSpiderConfigBackId(SpiderConfigRequest spiderConfigRequest){
		try{
			SpiderConfigEntity spiderConfigEntity = BeanHelper.copyTo(spiderConfigRequest,SpiderConfigEntity.class);
            spiderConfigServiceImpl.save(spiderConfigEntity);
            return new ServiceResponse<Long>(spiderConfigEntity.getId());
        } catch (BaseMsgException e) {
						LOGGER.error(String.format("保存信息出错！入参：[%s]",new Object[]{spiderConfigRequest}), e);
            return new ServiceResponse<Long>(BaseResponseCode.FAILURE,e.getMessage());
        } catch (Exception e){
            LOGGER.error(String.format("保存信息出错！入参：[%s]",new Object[]{spiderConfigRequest}), e);
            return new ServiceResponse<Long>(BaseResponseCode.SYSTEM_ERROR.getCode(),e.getMessage());
        }
	}

    @Override
    public ServiceResponse<SpiderConfigResponse> findSpiderConfigById(Long id) {
        try{
            return new ServiceResponse<SpiderConfigResponse>(BeanHelper.copyTo(spiderConfigServiceImpl.get(id), SpiderConfigResponse.class));
        } catch (BaseMsgException e) {
						LOGGER.error(String.format("根据id查询信息出错！入参：[%s]",new Object[]{id}), e);
            return new ServiceResponse<SpiderConfigResponse>(BaseResponseCode.FAILURE,e.getMessage());
        } catch (Exception e){
						LOGGER.error(String.format("根据id查询信息出错！入参：[%s]",new Object[]{id}), e);
            return new ServiceResponse<SpiderConfigResponse>(BaseResponseCode.SYSTEM_ERROR.getCode(),e.getMessage());
        }
    }

    @Override
    public ServiceResponse<Integer> updateSpiderConfig(SpiderConfigRequest spiderConfigRequest) {
        try{
            return new ServiceResponse<Integer>(spiderConfigServiceImpl.update(BeanHelper.copyTo(spiderConfigRequest,SpiderConfigEntity.class)));
        } catch (BaseMsgException e) {
						LOGGER.error(String.format("根据id更新信息出错！入参：[%s]",new Object[]{spiderConfigRequest}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.FAILURE,e.getMessage());
        } catch (Exception e){
            LOGGER.error(String.format("根据id更新信息出错！入参：[%s]",new Object[]{spiderConfigRequest}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.SYSTEM_ERROR.getCode(),e.getMessage());
        }
    }

    @Override
    public ServiceResponse<Integer> deleteSpiderConfig(Long id) {
        try{
            return new ServiceResponse<Integer>(spiderConfigServiceImpl.delete(id));
        } catch (BaseMsgException e) {
						LOGGER.error(String.format("根据id删除信息出错！入参：[%s]",new Object[]{id}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.FAILURE,e.getMessage());
        } catch (Exception e){
            LOGGER.error(String.format("根据id删除信息出错！入参：[%s]",new Object[]{id}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.SYSTEM_ERROR.getCode(),e.getMessage());
        }
    }
	
	@Override
    public ServiceResponse<Integer> deleteAllSpiderConfig(Long[] ids) {
        try{
						int succcessCount = 0;
            for(Long id:ids){
                succcessCount = succcessCount + spiderConfigServiceImpl.delete(id);
            }
            ServiceResponse<Integer> serviceResponse = new ServiceResponse<Integer>(succcessCount);
            int length = ids.length;
            if(succcessCount == length){
                return serviceResponse;
            }else{
                if(succcessCount > 0){
                    serviceResponse.setMsg(String.format("[%s]条记录操作成功，[%s]条记录操作失败！",new Object[]{succcessCount,length-succcessCount}));
                }else{
                    serviceResponse.setResponseCode(BaseResponseCode.FAILURE);
                }
                return serviceResponse;
            }
        } catch (BaseMsgException e) {
						LOGGER.error(String.format("根据ids批量删除信息出错！入参：[%s]",new Object[]{Arrays.toString(ids)}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.FAILURE,e.getMessage());
        } catch (Exception e){
            LOGGER.error(String.format("根据ids批量删除信息出错！入参：[%s]",new Object[]{Arrays.toString(ids)}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.SYSTEM_ERROR.getCode(),e.getMessage());
        }
    }

    @Override
    public ServiceResponse<Integer> saveAllSpiderConfig(List<SpiderConfigRequest> spiderConfigRequestList) {
        if(CollectionUtils.isEmpty(spiderConfigRequestList)){
            return new ServiceResponse<Integer>(0);
        }
        try{
            return new ServiceResponse<Integer>(spiderConfigServiceImpl.saveAll((List<SpiderConfigEntity>) BeanHelper.copyTo(spiderConfigRequestList,SpiderConfigEntity.class)));
        } catch (BaseMsgException e) {
						LOGGER.error(String.format("批量保存信息出错！入参：[%s]",new Object[]{JsonUtils.toJson(spiderConfigRequestList)}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.FAILURE,e.getMessage());
        } catch (Exception e){
						LOGGER.error(String.format("批量保存信息出错！入参：[%s]",new Object[]{JsonUtils.toJson(spiderConfigRequestList)}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.SYSTEM_ERROR.getCode(),e.getMessage());
        }
    }

    @Override
    public ServiceResponse<Integer> updateAllSpiderConfig(List<SpiderConfigRequest> spiderConfigRequestList) {
        if(CollectionUtils.isEmpty(spiderConfigRequestList)){
            return new ServiceResponse<Integer>(0);
        }
        try{
            return new ServiceResponse<Integer>(spiderConfigServiceImpl.updateAll((List<SpiderConfigEntity>) BeanHelper.copyTo(spiderConfigRequestList,SpiderConfigEntity.class)));
        } catch (BaseMsgException e) {
						LOGGER.error(String.format("批量根据id更新信息出错！入参：[%s]",new Object[]{JsonUtils.toJson(spiderConfigRequestList)}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.FAILURE,e.getMessage());
        } catch (Exception e){
            LOGGER.error(String.format("批量根据id更新信息出错！入参：[%s]",new Object[]{JsonUtils.toJson(spiderConfigRequestList)}), e);
            return new ServiceResponse<Integer>(BaseResponseCode.SYSTEM_ERROR.getCode(),e.getMessage());
        }
    }

}
