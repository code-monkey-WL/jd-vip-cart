package com.jd.o2o.vipcart.dao;
import com.jd.o2o.vipcart.domain.entity.SpiderConfigEntity;
import com.jd.o2o.road.common.dao.BaseDao;

public interface SpiderConfigDao extends BaseDao<SpiderConfigEntity, Long> {
	
}