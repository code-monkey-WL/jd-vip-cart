package com.jd.o2o.vipcart.web.controller;
import com.jd.o2o.commons.domain.PageBean;
import com.jd.o2o.commons.domain.enums.OperEnum;
import com.jd.o2o.commons.domain.response.BaseResponseCode;
import com.jd.o2o.commons.domain.response.ServiceResponse;
import com.jd.o2o.vipcart.api.SpiderConfigService;
import com.jd.o2o.road.common.utils.BeanHelper;
import com.jd.o2o.commons.domain.valid.*;
import com.jd.o2o.vipcart.domain.request.SpiderConfigInput;
import com.jd.o2o.vipcart.domain.request.SpiderConfigRequest;
import com.jd.o2o.vipcart.domain.response.SpiderConfigResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/spiderConfig")
public class SpiderConfigController extends BaseController {
	private static final Logger LOGGER = LoggerFactory.getLogger(SpiderConfigController.class);
    @Resource
    private SpiderConfigService spiderConfigServiceImpl;


    @RequestMapping(value = "/list")
    public ModelAndView list(HttpServletRequest request,SpiderConfigInput spiderConfigInput) {
        ModelAndView view = new ModelAndView("/spiderConfig/listSpiderConfig");
        view.addObject("result",spiderConfigServiceImpl.findListSpiderConfig(BeanHelper.copyTo(spiderConfigInput,SpiderConfigRequest.class)));
        return view;
    }
	
	@RequestMapping(value = "/plist")
    public ModelAndView pageList(HttpServletRequest request,SpiderConfigInput spiderConfigInput,PageBean pageBean) {
        ModelAndView view = new ModelAndView("/spiderConfig/listSpiderConfig");
		ServiceResponse<PageBean<SpiderConfigResponse>> serviceResponse = spiderConfigServiceImpl.findListPageSpiderConfig(BeanHelper.copyTo(spiderConfigInput,SpiderConfigRequest.class), pageBean);
        view.addObject("result", serviceResponse);
        view.addObject("page", serviceResponse.getResult());
        view.addObject("params",BeanHelper.modelToMap(spiderConfigInput));
        return view;
    }
	
	@RequestMapping(value = "/lists")
	public ModelAndView listSearch(HttpServletRequest request, SpiderConfigInput spiderConfigInput, PageBean pageBean) {
        ModelAndView view = new ModelAndView("/spiderConfig/listSearchSpiderConfig");
		ServiceResponse<PageBean<SpiderConfigResponse>> serviceResponse = spiderConfigServiceImpl.findListPageSpiderConfig(BeanHelper.copyTo(spiderConfigInput,SpiderConfigRequest.class), pageBean);
        view.addObject("result", serviceResponse);
        view.addObject("page", serviceResponse.getResult());
        view.addObject("params",BeanHelper.modelToMap(spiderConfigInput));
        return view;
    }
	
	 @RequestMapping(value = "/add")
    public ModelAndView add(HttpServletRequest request) {
        ModelAndView view = new ModelAndView("/spiderConfig/editSpiderConfig");
		view.addObject("result", new ServiceResponse<String>());
        return view;
    }
	
	@RequestMapping(value = "/save")
    public ModelAndView save(HttpServletRequest request,@Validated({SaveValid.class}) SpiderConfigInput spiderConfigInput, BindingResult errors) {
        ModelAndView view = new ModelAndView("/spiderConfig/plist");
		if(errors.hasErrors()){
            return view.addObject("errors", errors.getAllErrors());
        }
		buildBaseEntityBean(spiderConfigInput, spiderConfigInput.getId()==null? OperEnum.ADD:OperEnum.EDIT);
        ServiceResponse<Integer> serviceResponse = spiderConfigServiceImpl.saveSpiderConfig(BeanHelper.copyTo(spiderConfigInput,SpiderConfigRequest.class));
        view.addObject("result",serviceResponse.isSuccess() && serviceResponse.getResult() <= 0?new ServiceResponse<Integer>(BaseResponseCode.FAILURE):serviceResponse);
        return view;
    }
	
	@RequestMapping(value = "/edit/{id}")
    public ModelAndView edit(HttpServletRequest request,@PathVariable("id") Long id) {
        ModelAndView view = new ModelAndView("/spiderConfig/editSpiderConfig");
        ServiceResponse<SpiderConfigResponse> serviceResponse = spiderConfigServiceImpl.findSpiderConfigById(id);
        view.addObject("result",serviceResponse.getResult() == null?new ServiceResponse<SpiderConfigResponse>(BaseResponseCode.FAILURE):serviceResponse);
        return view;
    }
	
	@RequestMapping(value = "/update")
    public ModelAndView update(HttpServletRequest request,@Validated({ UpdateValid.class}) SpiderConfigInput spiderConfigInput, BindingResult errors) {
        ModelAndView view = new ModelAndView("/spiderConfig/plist");
		if(errors.hasErrors()){
            return view.addObject("errors", errors.getAllErrors());
        }
		buildBaseEntityBean(spiderConfigInput, OperEnum.EDIT);
        ServiceResponse<Integer> serviceResponse = spiderConfigServiceImpl.updateSpiderConfig(BeanHelper.copyTo(spiderConfigInput,SpiderConfigRequest.class));
        view.addObject("result",serviceResponse.isSuccess() && serviceResponse.getResult() <= 0?new ServiceResponse<Integer>(BaseResponseCode.FAILURE):serviceResponse);
        return view;
    }
	
	@RequestMapping(value = "/delete/{id}")
    public ModelAndView deletes(HttpServletRequest request,@PathVariable("id") Long[] ids) {
        ModelAndView view = new ModelAndView("/spiderConfig/plist");
        ServiceResponse<Integer> serviceResponse = spiderConfigServiceImpl.deleteAllSpiderConfig(ids);
        view.addObject("result",serviceResponse.isSuccess() && serviceResponse.getResult() <= 0?new ServiceResponse<Integer>(BaseResponseCode.FAILURE):serviceResponse);
        return view;
    }
}