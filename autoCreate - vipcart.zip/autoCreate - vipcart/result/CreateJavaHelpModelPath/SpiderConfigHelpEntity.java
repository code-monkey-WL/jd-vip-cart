package com.jd.o2o.vipcart.domain.entity;
import com.jd.o2o.commons.domain.BaseEntityBean;

public class SpiderConfigHelpEntity extends BaseEntityBean {
//Long, String, Integer, String, String, String, Integer, String, String, String, String, String, Integer, Integer, Integer, Integer, java.util.Date, String, Integer, java.util.Date, String, java.util.Date, String, Integer, Integer, java.util.Date 
//id, spiderName, spiderType, url, requestParam, content, ruleEngine, targetOut, outTableName, baseUrl, scanExpressions, itemRules, scheduledCron, deepNum, state, spiderNum, lastSpiderTime, remark, sort, createTime, createPin, updateTime, updatePin, sysVersion, yn, ts 
	public SpiderConfigEntity buildSpiderConfigEntity(SpiderConfigEntity param)
	{
		SpiderConfigEntity spiderConfigEntity = new SpiderConfigEntity();
		spiderConfigEntity.setId(param.getId());
		spiderConfigEntity.setSpiderName(param.getSpiderName());
		spiderConfigEntity.setSpiderType(param.getSpiderType());
		spiderConfigEntity.setUrl(param.getUrl());
		spiderConfigEntity.setRequestParam(param.getRequestParam());
		spiderConfigEntity.setContent(param.getContent());
		spiderConfigEntity.setRuleEngine(param.getRuleEngine());
		spiderConfigEntity.setTargetOut(param.getTargetOut());
		spiderConfigEntity.setOutTableName(param.getOutTableName());
		spiderConfigEntity.setBaseUrl(param.getBaseUrl());
		spiderConfigEntity.setScanExpressions(param.getScanExpressions());
		spiderConfigEntity.setItemRules(param.getItemRules());
		spiderConfigEntity.setScheduledCron(param.getScheduledCron());
		spiderConfigEntity.setDeepNum(param.getDeepNum());
		spiderConfigEntity.setState(param.getState());
		spiderConfigEntity.setSpiderNum(param.getSpiderNum());
		spiderConfigEntity.setLastSpiderTime(param.getLastSpiderTime());
		spiderConfigEntity.setRemark(param.getRemark());
		spiderConfigEntity.setSort(param.getSort());
		spiderConfigEntity.setCreateTime(param.getCreateTime());
		spiderConfigEntity.setCreatePin(param.getCreatePin());
		spiderConfigEntity.setUpdateTime(param.getUpdateTime());
		spiderConfigEntity.setUpdatePin(param.getUpdatePin());
		spiderConfigEntity.setSysVersion(param.getSysVersion());
		spiderConfigEntity.setYn(param.getYn());
		spiderConfigEntity.setTs(param.getTs());
		return spiderConfigEntity;
	}
}